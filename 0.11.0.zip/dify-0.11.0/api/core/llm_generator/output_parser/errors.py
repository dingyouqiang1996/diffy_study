class OutputParserError(Exception):
    pass
